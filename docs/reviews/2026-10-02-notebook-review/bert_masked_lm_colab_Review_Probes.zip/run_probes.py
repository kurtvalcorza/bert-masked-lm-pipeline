"""Review probes for tutorials/bert_masked_lm_colab.ipynb (prefix MLM), Notebook Review Framework v1.

Run from any directory:  python run_probes.py <repo_worktree> <workdir> <weights_src_dir>
  repo_worktree    checkout of kurtvalcorza/bert-masked-lm-pipeline at the reviewed SHA
  workdir          empty scratch directory used as the notebook's working directory
  weights_src_dir  a directory holding the digest-verified bert-base-uncased snapshot and the scitldr cache
                   (the snapshot's model.safetensors is hard-linked read-only; small files are copied)

Environment: CPU only, DIMER_NOTEBOOK_CI_PREINSTALLED=1 so cell 3 skips the pip install (versions are recorded,
not the pins). Code cells are executed verbatim from the notebook JSON in one namespace, in order; only form-field
literals are substituted (as an executor sets fields), and google.colab.files.upload is replaced by a fake for BYOD.
This is a local CPU run, not a Colab run, and the snapshot and corpus cache are pre-staged (not a clean runtime).
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import types
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
WORK = Path(sys.argv[2]).resolve()
WSRC = Path(sys.argv[3]).resolve()
NB_PATH = REPO / 'tutorials' / 'bert_masked_lm_colab.ipynb'
OUT = Path(__file__).resolve().parent / 'results.json'
RESULTS: dict = {}


def save():
    OUT.write_text(json.dumps(RESULTS, indent=2, default=str), encoding='utf-8')


def record(key, value):
    RESULTS[key] = value
    save()
    print(f'[probe] {key}: written', flush=True)


nb = json.loads(NB_PATH.read_text(encoding='utf-8'))
CELLS = nb['cells']
SRC = {i: ''.join(c['source']) for i, c in enumerate(CELLS)}
CODE = [i for i, c in enumerate(CELLS) if c['cell_type'] == 'code']

# ---------------- P0 static ----------------
p0 = {'code_cells': CODE, 'n_cells': len(CELLS)}
compiled = {}
for i in CODE:
    try:
        compile(SRC[i], f'cell{i}', 'exec')
        compiled[i] = True
    except SyntaxError as exc:
        compiled[i] = str(exc)
p0['compile'] = compiled
p0['blob'] = subprocess.run(['git', '-C', str(REPO), 'rev-parse', 'HEAD:tutorials/bert_masked_lm_colab.ipynb'],
                            capture_output=True, text=True).stdout.strip()
p0['head'] = subprocess.run(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], capture_output=True, text=True).stdout.strip()
p0['metadata_dimer'] = nb['metadata'].get('dimer')
md_all = '\n'.join(SRC[i] for i, c in enumerate(CELLS) if c['cell_type'] == 'markdown')
p0['doubled_braces_in_markdown'] = [i for i, c in enumerate(CELLS) if c['cell_type'] == 'markdown' and '{{' in SRC[i]]
markers = {
    'how_to_use': r'How to use this notebook', 'roadmap': r'[Rr]oadmap', 'input_model_output': r'Input\s*(→|->)',
    'predict': r'\b[Pp]redict(ion)?\b', 'what_to_notice': r'What to notice', 'check_reasoning': r'<details>|Check your reasoning',
    'glossary': r'[Gg]lossary', 'troubleshooting': r'[Tt]roubleshoot', 'infrastructure_label': r'Infrastructure',
    'conclusion_template': r'[Cc]onclusion', 'look_for': r'Look for', 'intended_learner': r'intended (learner|audience)|Level \d',
}
p0['guided_markers_in_markdown'] = {k: len(re.findall(v, md_all)) for k, v in markers.items()}
p0['cellView_form_cells'] = [i for i, c in enumerate(CELLS) if c.get('metadata', {}).get('cellView') == 'form']
p0['carried_cell_lines'] = {i: SRC[i].count('\n') + 1 for i in CODE if 'dimer' in CELLS[i].get('metadata', {})}
p0['restart_text_cell2'] = 'restart instruction' in SRC[2]
p0['in_kernel_pip_install_cell3'] = "'-m', 'pip', 'install'" in SRC[3]
p0['declared_spec_opening'] = re.findall(r'Notebook Specification (\d\.\d)', SRC[0])
p0['learning_objectives'] = re.search(r'\*\*Learning objectives:\*\*(.*)', SRC[0]).group(1).strip()[:400]
gen = subprocess.run([sys.executable, str(REPO / 'tools' / 'build_notebook.py'), '--check'], capture_output=True, text=True, cwd=REPO)
p0['generator_check'] = {'exit': gen.returncode, 'out': (gen.stdout + gen.stderr).strip()[-300:]}
val = subprocess.run([sys.executable, str(REPO / 'tools' / 'validate_release_assets.py')], capture_output=True, text=True, cwd=REPO)
p0['validate_release_assets'] = {'exit': val.returncode, 'out': (val.stdout + val.stderr).strip()[-300:]}
record('P0_static', p0)

# ---------------- execution harness ----------------
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ.setdefault('CUDA_VISIBLE_DEVICES', '-1')
wdir = WORK / 'weights' / 'bert-base-uncased'
if not wdir.exists():
    shutil.copytree(WSRC / 'bert-base-uncased', wdir, ignore=shutil.ignore_patterns('model.safetensors'))
    os.link(WSRC / 'bert-base-uncased' / 'model.safetensors', wdir / 'model.safetensors')
    shutil.copytree(WSRC / 'scitldr', WORK / 'weights' / 'scitldr')

UPLOAD: dict = {}
colab = types.ModuleType('google.colab')
colab.files = types.SimpleNamespace(upload=lambda: dict(UPLOAD))
google = types.ModuleType('google')
google.colab = colab
sys.modules['google'] = google
sys.modules['google.colab'] = colab


def with_fields(i, fields):
    src = SRC[i]
    for name, value in (fields or {}).items():
        pat = re.compile(rf'^{name} = .*$', re.M)
        if not pat.search(src):
            raise KeyError(f'field {name} not found in cell {i}')
        src = pat.sub(f'{name} = {value!r}', src, count=1)
    return src


def run_cell(ns, i, fields=None):
    buf = io.StringIO()
    t0 = time.perf_counter()
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(with_fields(i, fields), f'<cell {i}>', 'exec'), ns)
        return {'cell': i, 'ok': True, 's': round(time.perf_counter() - t0, 1), 'stdout': buf.getvalue()[-1500:]}
    except BaseException as exc:  # noqa: BLE001
        return {'cell': i, 'ok': False, 's': round(time.perf_counter() - t0, 1), 'stdout': buf.getvalue()[-800:],
                'error': f'{type(exc).__name__}: {exc}'[:600], 'tb_tail': traceback.format_exc()[-600:]}


def run_cells(ns, cells, fields=None, stop=True):
    out = []
    for i in cells:
        r = run_cell(ns, i, (fields or {}).get(i))
        out.append(r)
        print(f"  cell {i}: {'ok' if r['ok'] else r['error'][:120]} ({r['s']} s)", flush=True)
        if not r['ok'] and stop:
            break
    return out


def lstate(pipe):
    return {k: v.detach().clone() for k, v in pipe._model.state_dict().items()}


# ---------------- P1 default path, verbatim ----------------
ns = {'__name__': '__main__'}
p1 = {'cells': run_cells(ns, CODE)}
if all(c['ok'] for c in p1['cells']):
    p1['comparison'] = ns['comparison']
    p1['parity'] = ns['parity']
    p1['history'] = [{k: e.get(k) for k in ('epoch', 'train_loss', 'note')} | {'val_ppl': (e.get('val') or {}).get('perplexity')} for e in ns['adapt_result']['history']]
    p1['outputs'] = sorted(os.listdir('outputs'))
    p1['frozen_adapted_flag'] = ns['frozen_test']['adapted']
record('P1_default_path', p1)
if not all(c['ok'] for c in p1['cells']):
    sys.exit(1)

import torch  # noqa: E402

B = ns['BERTMaskedLMPipeline']
base = B.from_pretrained(weights_dir=ns['WEIGHTS_DIR'])
base_state = lstate(base)
val_frozen_true = base.evaluate(ns['val_records'], mask_rate=0.15, seed=0)['perplexity']


def layers_differing(pipe):
    st = pipe._model.state_dict()
    return sorted({int(k.split('.')[3]) for k in st if k.startswith('bert.encoder.layer.') and not torch.equal(st[k], base_state[k])})


# ---------------- P2a optional experiment TRAINABLE_LAYERS = 1, rerun from Section 7 ----------------
p2a = {'instruction': 'Interpretation: set TRAINABLE_LAYERS = 1 and watch the gain shrink (rerun Sections 7-9)',
       'layers_already_adapted_before_rerun': layers_differing(ns['pipe'])}
fields = {19: {'TRAINABLE_LAYERS': 1, 'EPOCHS': 1}}
p2a['cells'] = run_cells(ns, [19, 21, 23], fields=fields, stop=True)
p2a['epoch0_note_and_val_ppl'] = [(e.get('note'), (e.get('val') or {}).get('perplexity')) for e in ns['adapt_result']['history']][:1]
p2a['true_frozen_val_ppl'] = val_frozen_true
p2a['layers_adapted_in_pipe_after'] = layers_differing(ns['pipe'])
man = Path('outputs/bert_masked_lm_adapter/manifest.json')
if man.exists():
    tensors = json.loads(man.read_text(encoding='utf-8'))['tensors']
    p2a['artifact_layers'] = sorted({int(t.split('.')[3]) for t in tensors})
p2a['parity_seen'] = ns.get('parity')
p2a['comparison_after_rerun'] = ns.get('comparison')
record('P2a_trainable_layers_rerun', p2a)

# ---------------- P2b optional experiment: change SEED in Section 6 (rerun Section 6) ----------------
p2b = {'instruction': 'Interpretation: change SEED in Section 6 and read how much the masked metrics move'}
p2b['cells'] = run_cells(ns, [17], fields={17: {'SEED': 1}})
fresh = base.evaluate(ns['test_records'], mask_rate=0.15, seed=1)
p2b['section6_frozen_flag_adapted'] = ns['frozen_test']['adapted']
p2b['section6_frozen_ppl'] = ns['frozen_test']['perplexity']
p2b['fresh_frozen_ppl_seed1'] = fresh['perplexity']
record('P2b_seed_rerun', p2b)

# ---------------- P2c control: same TRAINABLE_LAYERS = 1 from a fresh pretrained pipe ----------------
ns['pipe'] = B.from_pretrained(weights_dir=ns['WEIGHTS_DIR'])
p2c = {'note': 'control: pipe rebuilt from the verified files before Section 6, then Sections 6-9 with TRAINABLE_LAYERS=1, EPOCHS=1'}
p2c['cells'] = run_cells(ns, [17, 19, 21, 23], fields={17: {'SEED': 0}, 19: {'TRAINABLE_LAYERS': 1, 'EPOCHS': 1}})
p2c['parity'] = ns.get('parity')
p2c['epoch0'] = [(e.get('note'), (e.get('val') or {}).get('perplexity')) for e in ns['adapt_result']['history']][:1]
record('P2c_fresh_control', p2c)

# ---------------- P3 BYOD ----------------
dev = [r for r in ns['filter_records'](ns['corpus']['dev'])]
abstracts = [r['text'] for r in dev]


def jsonl(texts, prefix='u'):
    return '\n'.join(json.dumps({'id': f'{prefix}{i:04d}', 'text': t}) for i, t in enumerate(texts)).encode('utf-8')


def byod_cell13(payload, name='mine.jsonl'):
    UPLOAD.clear()
    if payload is not None:
        UPLOAD[name] = payload
    return run_cell(ns, 13, {'USE_BYOD': True})


sweep = {}
for n in (8, 10, 20, 30, 37, 38, 40, 45, 49, 50, 60):
    r = byod_cell13(jsonl(abstracts[:n]))
    sweep[n] = 'accepted' if r['ok'] else r['error'][:160]
p3 = {'stated_contract': 'Prerequisites: a dataset needs 8..20,000 records', 'cell13_by_record_count': sweep,
      'smallest_accepted': next((n for n, v in sweep.items() if v == 'accepted'), None)}
r = byod_cell13(None)
p3['empty_upload'] = r.get('error', 'ok')
record('P3a_byod_minimum', p3)

# long-token record: under 4,000 chars but over 512 WordPiece tokens
long_text = ' '.join(['zqxv' + 'kjwp' * 3 + str(i % 10) for i in range(260)])[:3900]
texts = abstracts[:59] + [long_text]
ns['pipe'] = B.from_pretrained(weights_dir=ns['WEIGHTS_DIR'])
p3b = {'long_record_chars': len(long_text), 'long_record_tokens': len(ns['pipe']._encode(long_text))}
r13 = byod_cell13(jsonl(texts))
p3b['cell13'] = 'ok' if r13['ok'] else r13['error']
if r13['ok']:
    where = [n for n, part in ns['splits'].items() if any(x['text'] == long_text.strip() for x in part)]
    p3b['long_record_split'] = where
    p3b['later_cells'] = run_cells(ns, [15, 17, 19], fields={19: {'EPOCHS': 1}})
record('P3b_byod_token_ceiling', p3b)

# opening sentence without a 4+ letter word -> cloze_of
texts = ['We do it. ' + t for t in abstracts[:60]]
r13 = byod_cell13(jsonl(texts))
p3c = {'cell13': 'ok' if r13['ok'] else r13['error']}
if r13['ok']:
    p3c['cell15'] = run_cells(ns, [15])
record('P3c_byod_short_opening_sentence', p3c)

# positive BYOD control through Section 9 (TXT, blank-line paragraphs), fresh pipe, EPOCHS=1
ns['pipe'] = B.from_pretrained(weights_dir=ns['WEIGHTS_DIR'])
UPLOAD.clear()
UPLOAD['notes.txt'] = '\n\n'.join(abstracts[100:160]).encode('utf-8')
p3d = {'n_records': 60}
p3d['cells'] = run_cells(ns, [13, 15, 17, 19, 21, 23], fields={13: {'USE_BYOD': True}, 19: {'EPOCHS': 1}})
if all(c['ok'] for c in p3d['cells']):
    test_texts = [x['text'] for x in ns['test_records']]
    p3d['unseen_clozes_are_test_records'] = all(u['text'] in test_texts for u in ns['unseen_records'])
    p3d['parity'] = ns['parity']
    p3d['splits'] = ns['disjoint']
record('P3d_byod_positive', p3d)

# source manifest
files = [NB_PATH, REPO / 'tools' / 'build_notebook.py', REPO / 'tools' / 'notebook_template.py',
         REPO / 'tools' / 'validate_release_assets.py', REPO / 'src' / 'bert_masked_lm_pipeline' / 'pipeline.py',
         REPO / 'src' / 'bert_masked_lm_pipeline' / 'samples.py', REPO / 'src' / 'bert_masked_lm_pipeline' / 'metrics.py',
         REPO / 'tutorials' / 'README.md', REPO / 'docs' / 'release-verification.md', REPO / 'README.md', REPO / 'STATUS.md']
manifest = {str(f.relative_to(REPO)).replace('\\', '/'): hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
(Path(__file__).resolve().parent / 'source_manifest.json').write_text(json.dumps({'revision': p0['head'], 'files': manifest}, indent=2), encoding='utf-8')
record('done', True)
